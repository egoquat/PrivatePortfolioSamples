﻿[SCE CONFIDENTIAL DOCUMENT]
PhyreEngine(TM) Package 2.6.0
Copyright (C) 2009 Sony Computer Entertainment Inc.
All Rights Reserved.

メッシュ作成サンプル

概要
このサンプルでは、データベースを作成し設定する方法を示します。
シンプルなメッシュと光源がデータベースに追加されます。

キー
Q - アプリケーションを終了します。
W - ワイヤフレームモードのレンダリングを切り替えます。

カメラの動きの制御にはマウスまたはコントローラを使用します。

備考
なし

使用方法
createMesh

カテゴリ
Databases Scenes Meshes

変更履歴
2005年5月11日 0.1  オリジナル版
2006年3月21日 0.2  PSSG ExtraライブラリのcreateExampleDatabase()メソッドを
                   使用するよう変更。
2007年2月14日 0.3  メッシュの作成およびインスタンス化時に割り当てられた
                   オブジェクトの整列方法を変更。
2008年4月2 日 0.4  PSSG Extra deleteSegmentSet()メソッドを使用。
                   カメラコントロールの更新により、動きを改善。

