[SCE CONFIDENTIAL DOCUMENT]
PhyreEngine(TM) Package 2.7.0
Copyright (C) 2010 Sony Computer Entertainment Inc.
All Rights Reserved.
 
Create Mesh Sample

Introduction
This sample demonstrates how to create and populate a database. 
A simple mesh and a light is added to the database.

Keys
Q - Quit the application.
W - Toggle the rendering in wireframe mode.

Use mouse or controller to control camera movement.

Notes
None

Usage
createMesh

Categories
Databases Scenes Meshes

Changes
11/05/2005 0.1  Original Version
21/03/2006 0.2  Updated to use PSSG Extra library 
                createExampleDatabase() method.
14/02/2007 0.3  Updated with how to tidy up the objects allocated when
                creating and instancing a mesh.
02/04/2008 0.4  Make use of the PSSG Extra deleteSegmentSet() method.
                Updated the camera controls for better movement.